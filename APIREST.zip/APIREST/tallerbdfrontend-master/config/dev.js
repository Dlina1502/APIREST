module.exports = {
    posgresqlURI: 'postgres://sxwhdhfjcfevfs:7684e8c857cd7d18fde2f27989ea302aaff250cc5796d466644a04bf48ad84dc@ec2-184-73-249-9.compute-1.amazonaws.com:5432/defc6kfjk5hqlp',
};
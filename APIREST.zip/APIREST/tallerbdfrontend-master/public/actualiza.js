console.log('holaaa1');

var formulario_actualizar = document.getElementById('contact');

formulario_actualizar.addEventListener('submit', function(e) {
    console.log('correcto');
    e.preventDefault();
    console.log('me diste un click');
    let datos = new FormData(formulario_actualizar);
    let nombrepaciente = datos.get('nombre');
    let apellidopaciente = datos.get('apellido');
    let idpaciente = datos.get('identificacion');

    let myHeaders = new Headers();

    const options = {
        method: 'PUT',
        headers: myHeaders,
        body: new URLSearchParams({
            'nombre': nombrepaciente,
            'apellido': apellidopaciente,
            'numid': idpaciente
        }),
    }

    fetch('/basedatos/actualizarpacientes', options)
        .then((res) => res.json())
        .then((data) => {
            console.log(data);
        });
});
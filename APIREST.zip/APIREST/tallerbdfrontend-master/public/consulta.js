var formulario_consulta = document.getElementById('contact');

formulario_consulta.addEventListener('submit', function(e) {
    e.preventDefault();

    fetch('/basedatos/consultatotalpacientes')
        .then((res) => res.json())
        .then((data) => {
            console.log(data);
        });

});